/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package x.pkg1;

import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author WiZ14
 */
public class orderjdialog extends javax.swing.JDialog {
String user_typeid;
String whichordervar;
String table_queryvar;
String table_oidvar;
String table_values_ins;
String main_id;
String ref_id;
String ref_var;
String table_values_up;
String table_odatevar;



    /**
     * Creates new form orderjdialog
     */
    public orderjdialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    public orderjdialog(java.awt.Frame parent, boolean modal,String idvar1,String passvar1,String user_typevar) {
        super(parent, modal);
        initComponents();
        useridtext.setText(idvar1);Juser_type_Label.setText(user_typevar);
        whose_page(user_typevar);
        loaduserinfo(idvar1,passvar1,user_typeid);
       
        
    }
    
    public void whose_page(String user_typevar){
        if(user_typevar=="ADMIN"){user_typeid="aid";}
        
        else if(user_typevar=="SELLER"){user_typeid="pid";ref_var="phid";table_queryvar="PVLHTHS";whichordervar="order1";table_oidvar="o1id";
        table_values_ins="(o1id,dcode,pid,oquant,phref)";main_id=useridtext.getText();ref_id=phidtext.getText();table_values_up="o1id,dcode,pid,oquant,katastasi,o1date,phref,invoice";
        table_odatevar="o1date";}
        
        else if(user_typevar=="PHARMACIST"){user_typeid="phid";ref_var="pid";table_queryvar="PHARMAKOPOIOS";whichordervar="order2";table_oidvar="o2id";
        table_values_ins="(o2id,dcode,phid,oquant,pref)";main_id=useridtext.getText();ref_id=pidtext.getText();table_values_up="o2id,dcode,phid,oquant,katastasi,o2date,pref,invoice";
        table_odatevar="o2date";}
    }
    
    public void loaduserinfo(String idvar2,String passvar2,String user_typeidvar){

        String query5="SELECT FNAME,LNAME "
                + "FROM "+table_queryvar+""
                + " where "+ user_typeid+"='"+idvar2
                +"' AND PASS='"+passvar2+"'";
        System.out.println(query5);
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement();
                searchRS=searchStm.executeQuery(query5);
              // clearTable((javax.swing.table.DefaultTableModel)jMemberTable.getModel());
               if(searchRS.next()){
       //String s=searchRS.getString("FNAME");
       //String s2=searchRS.getString("LNAME");
       userfnametext.setText(searchRS.getString("FNAME"));
       userlnametext.setText(searchRS.getString("LNAME"));
               }
           

                   
               searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
    }
    

    public void insertOrderAction(){
    String query1="INSERT INTO "+whichordervar+" "+table_values_ins+""+
                    "VALUES(O1SEQ.nextval, "+
                    "'"+dcodetext.getText()+"',"+
                    "'"+main_id+"',"+
                    "'"+oquanttext.getText()+"',"+
                    "'"+ref_id+"')"
                    
                ;
        
        System.out.println(query1);
        
        java.sql.Statement insertStmt;
        try {
            insertStmt =  connectloginjframe.con1.createStatement();
            insertStmt.executeQuery(query1);
            insertStmt.close();
        }
        catch( java.sql.SQLException e4) {
             JOptionPane.showMessageDialog( this , e4.getMessage() );
        }
    }
    
    public void clearTable(javax.swing.table.DefaultTableModel model){
         int numrows =model.getRowCount();
         for (int i =numrows-1;i>=0;i--){
             model.removeRow(i);
         }
     }
    public void loadorders(){
    String query4="SELECT "+ table_values_up +" FROM "+ whichordervar
                + " where "+user_typeid +" = '"+main_id+"'";
     
        //o2id,dcode,phid,oquant,katastasi,o2date,pref,invoice
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;System.out.println(query4);System.out.println(table_oidvar +"  " +user_typeid +"  " + table_odatevar+"  " +ref_var);
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
              clearTable((javax.swing.table.DefaultTableModel)orderstable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) orderstable.getModel()).addRow(
        new Object[]{
           searchRS.getString(1),
           searchRS.getString("dcode"),
           searchRS.getString(3),
           searchRS.getString("oquant"),
           searchRS.getString("katastasi"),
           searchRS.getString(6),
           searchRS.getString(7),
           searchRS.getString("invoice")
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}    
    }
    
    public void TableMouseClickedAction(){
        if((orderstable.getSelectedRow() )<0)return;
order_idtext.setText(""+orderstable.getModel().getValueAt(orderstable.getSelectedRow(),0));
dcodetext.setText(""+orderstable.getModel().getValueAt(orderstable.getSelectedRow(),1));
phidtext.setText(""+orderstable.getModel().getValueAt(orderstable.getSelectedRow(),2));
oquanttext.setText(""+orderstable.getModel().getValueAt(orderstable.getSelectedRow(),3));
katastasitext.setText(""+orderstable.getModel().getValueAt(orderstable.getSelectedRow(),4));
odate.setText(""+orderstable.getModel().getValueAt(orderstable.getSelectedRow(),5));
pidtext.setText(""+orderstable.getModel().getValueAt(orderstable.getSelectedRow(),6));
invoicetext.setText(""+orderstable.getModel().getValueAt(orderstable.getSelectedRow(),7));}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        userfnametext = new javax.swing.JTextField();
        userlnametext = new javax.swing.JTextField();
        Juser_type_Label = new javax.swing.JLabel();
        useridtext = new javax.swing.JTextField();
        JFirstnameLabel1 = new javax.swing.JLabel();
        JLastnameLabel1 = new javax.swing.JLabel();
        backbutton = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        orderstable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        JFirstnameLabel = new javax.swing.JLabel();
        JRegdateLabel = new javax.swing.JLabel();
        JIDLabel = new javax.swing.JLabel();
        order_idtext = new javax.swing.JTextField();
        dcodetext = new javax.swing.JTextField();
        phidtext = new javax.swing.JTextField();
        oquanttext = new javax.swing.JTextField();
        katastasitext = new javax.swing.JTextField();
        JRegdateLabel3 = new javax.swing.JLabel();
        JPIDLabel = new javax.swing.JLabel();
        odate = new javax.swing.JTextField();
        JLastnameLabel = new javax.swing.JLabel();
        updatebutton = new javax.swing.JButton();
        pidtext = new javax.swing.JTextField();
        Seller_Reference_id = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        insertbutton = new javax.swing.JButton();
        invoicetext = new javax.swing.JTextField();
        JRegdateLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        userfnametext.setToolTipText("");

        Juser_type_Label.setText("PHARMACIST");

        useridtext.setEditable(false);
        useridtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                useridtextActionPerformed(evt);
            }
        });

        JFirstnameLabel1.setText("lname");

        JLastnameLabel1.setText("fname");
        JLastnameLabel1.setToolTipText("");

        backbutton.setText("back");
        backbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbuttonActionPerformed(evt);
            }
        });

        jLabel5.setText("HEAD TO:");

        orderstable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order_id", "dcode", "Pharmacist_id", "Quantity", "Order_state", "Order_date", "Seller_id", "Invoice"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        orderstable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                orderstableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(orderstable);

        jLabel1.setText("ORDERS");

        JFirstnameLabel.setText("Pharmacist_id");

        JRegdateLabel.setText("Quantity");

        JIDLabel.setText("Order_State");

        order_idtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                order_idtextActionPerformed(evt);
            }
        });

        dcodetext.setText("s1");
        dcodetext.setToolTipText("");

        phidtext.setText("1");
        phidtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phidtextActionPerformed(evt);
            }
        });

        oquanttext.setText("3");
        oquanttext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                oquanttextActionPerformed(evt);
            }
        });

        katastasitext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                katastasitextActionPerformed(evt);
            }
        });

        JRegdateLabel3.setText("Order_Date");

        JPIDLabel.setText("order_id");

        odate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                odateActionPerformed(evt);
            }
        });

        JLastnameLabel.setText("dcode");
        JLastnameLabel.setToolTipText("");

        updatebutton.setText("Update");
        updatebutton.setEnabled(false);
        updatebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebuttonActionPerformed(evt);
            }
        });

        pidtext.setText("1");
        pidtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pidtextActionPerformed(evt);
            }
        });

        Seller_Reference_id.setText("Seller_id");

        jLabel3.setText("Drug Information");

        insertbutton.setText("Insert");
        insertbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertbuttonActionPerformed(evt);
            }
        });

        invoicetext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invoicetextActionPerformed(evt);
            }
        });

        JRegdateLabel5.setText("Invoice");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Juser_type_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(JLastnameLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(JFirstnameLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(519, 519, 519)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JRegdateLabel)
                            .addComponent(JIDLabel)
                            .addComponent(JRegdateLabel3))
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(oquanttext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(katastasitext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(odate, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pidtext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(invoicetext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel3)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JLastnameLabel)
                            .addComponent(JFirstnameLabel)
                            .addComponent(JPIDLabel))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(order_idtext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dcodetext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phidtext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(Seller_Reference_id)
                    .addComponent(JRegdateLabel5))
                .addGap(80, 80, 80)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(insertbutton)
                    .addComponent(updatebutton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(backbutton)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JLastnameLabel1)
                        .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(JFirstnameLabel1)
                        .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Juser_type_Label)
                        .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(backbutton))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(insertbutton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(updatebutton))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JPIDLabel)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(order_idtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(dcodetext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JLastnameLabel))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(phidtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JFirstnameLabel))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JRegdateLabel)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(oquanttext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(katastasitext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JIDLabel))
                                        .addGap(4, 4, 4)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(odate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JRegdateLabel3))))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(pidtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Seller_Reference_id))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(invoicetext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JRegdateLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void useridtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_useridtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_useridtextActionPerformed

    private void backbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbuttonActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_backbuttonActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // TODO add your handling code here:
        loadorders();
    }//GEN-LAST:event_formComponentShown

    private void order_idtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_order_idtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_order_idtextActionPerformed

    private void oquanttextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_oquanttextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_oquanttextActionPerformed

    private void katastasitextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_katastasitextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_katastasitextActionPerformed

    private void odateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_odateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_odateActionPerformed

    private void updatebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebuttonActionPerformed
        // TODO add your handling code here:
       // updateOrderAction();loadorders();
    }//GEN-LAST:event_updatebuttonActionPerformed

    private void pidtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pidtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pidtextActionPerformed

    private void insertbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertbuttonActionPerformed
        // TODO add your handling code here:
        insertOrderAction();loadorders();
    }//GEN-LAST:event_insertbuttonActionPerformed

    private void invoicetextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invoicetextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_invoicetextActionPerformed

    private void phidtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phidtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phidtextActionPerformed

    private void orderstableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_orderstableMouseClicked
        // TODO add your handling code here:
        TableMouseClickedAction();
    }//GEN-LAST:event_orderstableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(orderjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(orderjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(orderjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(orderjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                orderjdialog dialog = new orderjdialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JFirstnameLabel;
    private javax.swing.JLabel JFirstnameLabel1;
    private javax.swing.JLabel JIDLabel;
    private javax.swing.JLabel JLastnameLabel;
    private javax.swing.JLabel JLastnameLabel1;
    private javax.swing.JLabel JPIDLabel;
    private javax.swing.JLabel JRegdateLabel;
    private javax.swing.JLabel JRegdateLabel3;
    private javax.swing.JLabel JRegdateLabel5;
    private javax.swing.JLabel Juser_type_Label;
    private javax.swing.JLabel Seller_Reference_id;
    private javax.swing.JButton backbutton;
    private javax.swing.JTextField dcodetext;
    private javax.swing.JButton insertbutton;
    private javax.swing.JTextField invoicetext;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField katastasitext;
    private javax.swing.JTextField odate;
    private javax.swing.JTextField oquanttext;
    private javax.swing.JTextField order_idtext;
    private javax.swing.JTable orderstable;
    private javax.swing.JTextField phidtext;
    private javax.swing.JTextField pidtext;
    private javax.swing.JButton updatebutton;
    private javax.swing.JTextField userfnametext;
    private javax.swing.JTextField useridtext;
    private javax.swing.JTextField userlnametext;
    // End of variables declaration//GEN-END:variables
}
