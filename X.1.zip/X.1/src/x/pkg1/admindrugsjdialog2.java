/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package x.pkg1;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author WiZ14
 */
public class admindrugsjdialog2 extends javax.swing.JDialog {
String user_typeid;
String table_queryvar;
    /**
     * Creates new form admindrugsjdialog2
     */
    public admindrugsjdialog2(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    public admindrugsjdialog2(java.awt.Frame parent, boolean modal,String idvar1,String passvar1,String user_typevar) {
        super(parent, modal);
        initComponents();
        useridtext.setText(idvar1);Juser_type_Label.setText(user_typevar);
        whose_page(user_typevar);
        loaduserinfo(idvar1,passvar1,user_typeid);
       
        
    }
    
    public void whose_page(String user_typevar){
        if(user_typevar=="ADMIN"){insertbutton.setEnabled(true);deletebutton.setEnabled(true);updatebutton.setEnabled(true);user_typeid="aid";table_queryvar=Juser_type_Label.getText();}
        else if(user_typevar=="SELLER"){insertbutton.setEnabled(false);deletebutton.setEnabled(false);updatebutton.setEnabled(false);user_typeid="pid";table_queryvar="PVLHTHS";}
        else if(user_typevar=="PHARMACIST"){insertbutton.setEnabled(false);deletebutton.setEnabled(false);updatebutton.setEnabled(false);user_typeid="phid";table_queryvar="PHARMAKOPOIOS";}
    }
    
    public void loaduserinfo(String idvar2,String passvar2,String user_typeidvar){

        String query5="SELECT FNAME,LNAME "
                + "FROM "+table_queryvar+""
                + " where "+ user_typeid+"='"+idvar2
                +"' AND PASS='"+passvar2+"'";
        System.out.println(query5);
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement();
                searchRS=searchStm.executeQuery(query5);
              // clearTable((javax.swing.table.DefaultTableModel)jMemberTable.getModel());
               if(searchRS.next()){
       //String s=searchRS.getString("FNAME");
       //String s2=searchRS.getString("LNAME");
       userfnametext.setText(searchRS.getString("FNAME"));
       userlnametext.setText(searchRS.getString("LNAME"));
               }
           

                   
               searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
    }
    public void insertDrugAction() {
String query1="INSERT INTO DRUGS (dcode,dname,dcat,company,dquality,sellprice) " + //dcode,dname,dcat,company,dquality,sellprice,profitmonth,profityear,dquant
                    "VALUES("+ 
                    "'"+dcodetext.getText()+"',"+
                    "'"+dnametext.getText()+"',"+
                    "'"+dcattext.getText()+"',"+
                    "'"+companytext.getText()+"',"+
                    "'"+dqualitytext.getText()+"',"+
                    "'"+sellpricetext.getText()+"')"
                ;
        
        System.out.println(query1);
        
        java.sql.Statement insertStmt;
        try {
            insertStmt =  connectloginjframe.con1.createStatement();
            insertStmt.executeQuery(query1);
            insertStmt.close();
        }
        catch( java.sql.SQLException e4) {
             JOptionPane.showMessageDialog( this , e4.getMessage() );
        }
        
    }
    
    
    
     public void deleteDrugAction() {
        String query3="DELETE FROM DRUGS WHERE dcode='"+dcodetext.getText()+"'";
             
                

        System.out.println(query3);

        java.sql.Statement deleteStm;
                try{deleteStm=connectloginjframe.con1.createStatement();
                deleteStm.executeQuery(query3);
                deleteStm.close();}
                catch(SQLException e6){
                    JOptionPane.showMessageDialog(this,e6.getMessage());}
        
        
    }
     public void updateDrugAction() {
        String query2="UPDATE DRUGS "+
                "SET dname='"+dnametext.getText()+"',"+
                "dcat='"+dcattext.getText()+"',"+
                "company='"+companytext.getText()+"',"+
                "dquality='"+dqualitytext.getText()+"',"+
                "sellprice='"+sellpricetext.getText()+"'"+
                "WHERE dcode='"+dcodetext.getText()+"'";
                
System.out.println(query2);
        java.sql.Statement updateStm;
                try {
            updateStm =  connectloginjframe.con1.createStatement();
            updateStm.executeQuery(query2);
            updateStm.close();
        }
        catch( java.sql.SQLException e5) {
             JOptionPane.showMessageDialog( this , e5.getMessage() );
        }
    }
     
     public void clearTable(javax.swing.table.DefaultTableModel model){
         int numrows =model.getRowCount();
         for (int i =numrows-1;i>=0;i--){
             model.removeRow(i);
         }
     }
     
     public void loaddrugs(){
        String query4="SELECT dcode,dname,dcat,company,dquality,sellprice,profitmonth,profityear,dquant "
                + "FROM DRUGS "
                + "ORDER BY dcode ASC";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
              clearTable((javax.swing.table.DefaultTableModel)drugsjtable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) drugsjtable.getModel()).addRow(
        new Object[]{
           searchRS.getString("dcode"),
           searchRS.getString("dname"),
           searchRS.getString("dcat"),
           searchRS.getString("company"),
           searchRS.getString("dquality"),
           searchRS.getString("sellprice"),
           searchRS.getString("profitmonth"),
           searchRS.getString("profityear"),
           searchRS.getString("dquant")
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
public void TableMouseClickedAction(){
        if((drugsjtable.getSelectedRow() )<0)return;
dcodetext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),0));
dnametext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),1));
dcattext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),2));
companytext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),3));
dqualitytext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),4));
dqualitytext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),5));
sellpricetext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),6));
dquantitytext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),7));
monthlyprofittext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),8));
yearhlyprofittext.setText(""+drugsjtable.getModel().getValueAt(drugsjtable.getSelectedRow(),9));}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        drugsjtable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        JPIDLabel = new javax.swing.JLabel();
        JLastnameLabel = new javax.swing.JLabel();
        Juser_type_Label = new javax.swing.JLabel();
        useridtext = new javax.swing.JTextField();
        JFirstnameLabel1 = new javax.swing.JLabel();
        JLastnameLabel1 = new javax.swing.JLabel();
        userfnametext = new javax.swing.JTextField();
        userlnametext = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        insertbutton = new javax.swing.JButton();
        JFirstnameLabel = new javax.swing.JLabel();
        backbutton = new javax.swing.JButton();
        JRegdateLabel = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        JIDLabel = new javax.swing.JLabel();
        deletebutton = new javax.swing.JButton();
        dcodetext = new javax.swing.JTextField();
        dnametext = new javax.swing.JTextField();
        dcattext = new javax.swing.JTextField();
        companytext = new javax.swing.JTextField();
        dqualitytext = new javax.swing.JTextField();
        JRegdateLabel3 = new javax.swing.JLabel();
        sellpricetext = new javax.swing.JTextField();
        updatebutton = new javax.swing.JButton();
        dquantitytext = new javax.swing.JTextField();
        JRegdateLabel4 = new javax.swing.JLabel();
        JRegdateLabel5 = new javax.swing.JLabel();
        monthlyprofittext = new javax.swing.JTextField();
        JRegdateLabel6 = new javax.swing.JLabel();
        yearhlyprofittext = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        drugsjtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "dcode", "name", "category", "company", "quality", "selling_price", "monthly_profit", "yearly_profit", "quantity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        drugsjtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                drugsjtableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(drugsjtable);

        jLabel1.setText("DRUGS");

        JPIDLabel.setText("dcode");

        JLastnameLabel.setText("name");
        JLastnameLabel.setToolTipText("");

        Juser_type_Label.setText("ADMIN");

        useridtext.setEditable(false);
        useridtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                useridtextActionPerformed(evt);
            }
        });

        JFirstnameLabel1.setText("lname");

        JLastnameLabel1.setText("fname");
        JLastnameLabel1.setToolTipText("");

        userfnametext.setEditable(false);
        userfnametext.setToolTipText("");

        userlnametext.setEditable(false);

        jLabel3.setText("Drug Information");

        insertbutton.setText("Insert");
        insertbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertbuttonActionPerformed(evt);
            }
        });

        JFirstnameLabel.setText("category");

        backbutton.setText("back");
        backbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbuttonActionPerformed(evt);
            }
        });

        JRegdateLabel.setText("company");

        jLabel5.setText("HEAD TO:");

        JIDLabel.setText("quality");

        deletebutton.setText("Delete");
        deletebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebuttonActionPerformed(evt);
            }
        });

        dcodetext.setText("1");
        dcodetext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dcodetextActionPerformed(evt);
            }
        });

        dnametext.setText("n1");
        dnametext.setToolTipText("");

        dcattext.setText("c1");

        companytext.setText("c1");
        companytext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                companytextActionPerformed(evt);
            }
        });

        dqualitytext.setText("q1");
        dqualitytext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dqualitytextActionPerformed(evt);
            }
        });

        JRegdateLabel3.setText("selling price");

        sellpricetext.setText("6");
        sellpricetext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sellpricetextActionPerformed(evt);
            }
        });

        updatebutton.setText("Update");
        updatebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebuttonActionPerformed(evt);
            }
        });

        dquantitytext.setText("6");
        dquantitytext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dquantitytextActionPerformed(evt);
            }
        });

        JRegdateLabel4.setText("quantity");

        JRegdateLabel5.setText("monthly_profit");

        monthlyprofittext.setText("6");
        monthlyprofittext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monthlyprofittextActionPerformed(evt);
            }
        });

        JRegdateLabel6.setText("yearly_profit");

        yearhlyprofittext.setText("6");
        yearhlyprofittext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearhlyprofittextActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JLastnameLabel)
                                    .addComponent(JFirstnameLabel)
                                    .addComponent(JPIDLabel))
                                .addGap(22, 22, 22)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dcodetext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dcattext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(backbutton))))
                .addGap(94, 94, 94))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JRegdateLabel)
                            .addComponent(JIDLabel))
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(companytext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dqualitytext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dquantitytext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(deletebutton)
                            .addComponent(insertbutton)
                            .addComponent(updatebutton))
                        .addGap(20, 20, 20))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Juser_type_Label)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(53, 53, 53)
                                        .addComponent(JLastnameLabel1)
                                        .addGap(18, 18, 18)
                                        .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(JFirstnameLabel1)
                                        .addGap(17, 17, 17))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(JRegdateLabel4)
                                                .addGap(95, 95, 95))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(JRegdateLabel3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(sellpricetext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(33, 33, 33)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(JRegdateLabel6)
                                                .addGap(18, 18, 18)
                                                .addComponent(yearhlyprofittext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(JRegdateLabel5)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(monthlyprofittext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(18, 18, Short.MAX_VALUE)))
                        .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(344, 344, 344))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Juser_type_Label)
                                    .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(40, 40, 40)
                                .addComponent(jLabel3))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(JLastnameLabel1)
                                .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(JFirstnameLabel1)
                                .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JPIDLabel)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(dcodetext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(dnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JLastnameLabel))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(dcattext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JFirstnameLabel))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JRegdateLabel)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(companytext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(dqualitytext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JIDLabel))))
                                .addGap(31, 31, 31))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(insertbutton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deletebutton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(updatebutton)
                                .addGap(33, 33, 33)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(monthlyprofittext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(JRegdateLabel5)
                                    .addComponent(sellpricetext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(JRegdateLabel3)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(backbutton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dquantitytext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JRegdateLabel4)
                    .addComponent(yearhlyprofittext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JRegdateLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void useridtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_useridtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_useridtextActionPerformed

    private void insertbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertbuttonActionPerformed
        // TODO add your handling code here:
        insertDrugAction();loaddrugs();
    }//GEN-LAST:event_insertbuttonActionPerformed

    private void deletebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebuttonActionPerformed
        // TODO add your handling code here:
        deleteDrugAction();loaddrugs();
    }//GEN-LAST:event_deletebuttonActionPerformed

    private void dcodetextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dcodetextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dcodetextActionPerformed

    private void companytextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_companytextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_companytextActionPerformed

    private void dqualitytextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dqualitytextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dqualitytextActionPerformed

    private void sellpricetextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sellpricetextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sellpricetextActionPerformed

    private void backbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbuttonActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_backbuttonActionPerformed

    private void updatebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebuttonActionPerformed
        // TODO add your handling code here:
        updateDrugAction();loaddrugs();
    }//GEN-LAST:event_updatebuttonActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // TODO add your handling code here:
        loaddrugs();
    }//GEN-LAST:event_formComponentShown

    private void dquantitytextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dquantitytextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dquantitytextActionPerformed

    private void drugsjtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_drugsjtableMouseClicked
        // TODO add your handling code here:
        TableMouseClickedAction();
    }//GEN-LAST:event_drugsjtableMouseClicked

    private void monthlyprofittextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monthlyprofittextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_monthlyprofittextActionPerformed

    private void yearhlyprofittextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearhlyprofittextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_yearhlyprofittextActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admindrugsjdialog2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admindrugsjdialog2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admindrugsjdialog2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admindrugsjdialog2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                admindrugsjdialog2 dialog = new admindrugsjdialog2(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JFirstnameLabel;
    private javax.swing.JLabel JFirstnameLabel1;
    private javax.swing.JLabel JIDLabel;
    private javax.swing.JLabel JLastnameLabel;
    private javax.swing.JLabel JLastnameLabel1;
    private javax.swing.JLabel JPIDLabel;
    private javax.swing.JLabel JRegdateLabel;
    private javax.swing.JLabel JRegdateLabel3;
    private javax.swing.JLabel JRegdateLabel4;
    private javax.swing.JLabel JRegdateLabel5;
    private javax.swing.JLabel JRegdateLabel6;
    private javax.swing.JLabel Juser_type_Label;
    private javax.swing.JButton backbutton;
    private javax.swing.JTextField companytext;
    private javax.swing.JTextField dcattext;
    private javax.swing.JTextField dcodetext;
    private javax.swing.JButton deletebutton;
    private javax.swing.JTextField dnametext;
    private javax.swing.JTextField dqualitytext;
    private javax.swing.JTextField dquantitytext;
    private javax.swing.JTable drugsjtable;
    private javax.swing.JButton insertbutton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField monthlyprofittext;
    private javax.swing.JTextField sellpricetext;
    private javax.swing.JButton updatebutton;
    private javax.swing.JTextField userfnametext;
    private javax.swing.JTextField useridtext;
    private javax.swing.JTextField userlnametext;
    private javax.swing.JTextField yearhlyprofittext;
    // End of variables declaration//GEN-END:variables
}
