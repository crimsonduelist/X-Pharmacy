/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package x.pkg1;

import java.sql.CallableStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import static x.pkg1.connectloginjframe.con1;

/**
 *
 * @author WiZ14
 */
public class sellerjdialog extends javax.swing.JDialog {
public String idvar3;
public String passvar3;
    /**
     * Creates new form sellerjdial
     */
    public sellerjdialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    public sellerjdialog(java.awt.Frame parent, boolean modal,String idvar1,String passvar1) {
        super(parent, modal);
        initComponents();
        idvar3=idvar1;passvar3=passvar1;
        useridtext.setText(idvar1);
        loadsellerinfo(idvar1,passvar1);
       
        
    }
    
    public void executeStoredProcedure(){
    try(
            CallableStatement cstmt = con1.prepareCall("{call is_user(?,?,?,?)}");) {
        cstmt.setString("userid",idvar3);
        cstmt.setString("passvar",passvar3);
        cstmt.setString("usertype",Juser_type_Label.getText());
        cstmt.registerOutParameter ("is_userout", java.sql.Types.INTEGER);  
        cstmt.execute();  
        System.out.println("MANAGER ID: " + cstmt.getInt("is_userout"));
        
        if (cstmt.getInt("is_userout")==1){
            c_userpassAction();
        
        }//System.out.println(cstmt+"asdfadsfa");
        cstmt.close();
    }
    catch( java.sql.SQLException exc5) {
             javax.swing.JOptionPane.showMessageDialog(this,exc5.getMessage());
        }
}
    public void c_userpassAction(){
        String query2="UPDATE PVLHTHS "+
                "SET PASS='"+c_passtotext.getText()+"' "+
                "WHERE PID='"+useridtext.getText()+"'";
                
System.out.println(query2);
        java.sql.Statement updateStm;
                try {
            updateStm =  connectloginjframe.con1.createStatement();
            updateStm.executeQuery(query2);
            updateStm.close();
            exitAction();
        }
        catch( java.sql.SQLException e5) {
             JOptionPane.showMessageDialog( this , e5.getMessage() );
        }
    }
    
    
    public void loadsellerinfo(String idvar2,String passvar2){
        
        String query5="SELECT FNAME,LNAME "
                + "FROM PVLHTHS "
                + " where PID='"+idvar2
                +"' AND PASS='"+passvar2+"'";
        System.out.println(query5);
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement();
                searchRS=searchStm.executeQuery(query5);
              // clearTable((javax.swing.table.DefaultTableModel)jMemberTable.getModel());
               if(searchRS.next()){
       //String s=searchRS.getString("FNAME");
       //String s2=searchRS.getString("LNAME");
       userfnametext.setText(searchRS.getString("FNAME"));
       userlnametext.setText(searchRS.getString("LNAME"));
               }
           

                   
               searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
    }
    public void loadsellers(){
        String query4="SELECT PID,FNAME,LNAME,GAIN,EMAIL "
                + "FROM pvlhths WHERE PID='"+useridtext.getText()+"'";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
               clearTable((javax.swing.table.DefaultTableModel)sellerjtable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) sellerjtable.getModel()).addRow(
        new Object[]{
           searchRS.getString("PID"),
           searchRS.getString("FNAME"),
           searchRS.getString("LNAME"),
           searchRS.getString("GAIN"),
           searchRS.getString("EMAIL")
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
    
    public void loadpharmacists(){
        String query4="SELECT PHID,PID,FNAME,LNAME,EMAIL "
                + "FROM PHARMAKOPOIOS "
                + "WHERE PHARMAKOPOIOS.PID='"+useridtext.getText()+"'";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
               
               clearTable((javax.swing.table.DefaultTableModel)pharmacistjtable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) pharmacistjtable.getModel()).addRow(
        new Object[]{
           searchRS.getString("PHID"),
           searchRS.getString("PID"),
           searchRS.getString("FNAME"),
           searchRS.getString("LNAME"),
           searchRS.getString("EMAIL")
           
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
    
    public void clearTable(javax.swing.table.DefaultTableModel model){
         int numrows =model.getRowCount();
         for (int i =numrows-1;i>=0;i--){
             model.removeRow(i);
         }
     }
    
    
    
    
    public void exitAction(){
        //connectbuttonpressed=false;
        this.dispose();
    }
    
    public void insertPharmacistAction() {
String query1="INSERT INTO PHARMAKOPOIOS(PHID,PID,FNAME,LNAME,EMAIL) " +
                    "VALUES("+ 
                    "PHSeq.NEXTVAL,"+"'"+useridtext.getText()+"',"+
                    "'"+phfnametext.getText()+"',"+
                    "'"+phlnametext.getText()+"',"+
                    "'"+phemailtext.getText()+"')"
                    
                ;
        
        System.out.println(query1);
        
        java.sql.Statement insertStmt;
        try {
            insertStmt =  connectloginjframe.con1.createStatement();
            insertStmt.executeQuery(query1);
            insertStmt.close();
        }
        catch( java.sql.SQLException e4) {
             JOptionPane.showMessageDialog( this , e4.getMessage() );
        }
        
    }
    
    public void updateSellerAction() {
        String query2="UPDATE PVLHTHS "+
                "SET FNAME='"+pfnametext.getText()+"',"+
                "LNAME='"+plnametext.getText()+"',"+
                "EMAIL='"+pemailtext.getText()+"' "+
                "WHERE PID='"+useridtext.getText()+"'";
                
System.out.println(query2);
        java.sql.Statement updateStm;
                try {
            updateStm =  connectloginjframe.con1.createStatement();
            updateStm.executeQuery(query2);
            updateStm.close();
        }
        catch( java.sql.SQLException e5) {
             JOptionPane.showMessageDialog( this , e5.getMessage() );
        }
    }
    
    public void STableMouseClickedAction(){
        if((sellerjtable.getSelectedRow() )<0)return;
pfnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),1));
plnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),2));
pemailtext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),3));
pemailtext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),4));}
  
     public void PhTableMouseClickedAction(){
        if((pharmacistjtable.getSelectedRow() )<0)return;
phidtext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),1));
pfnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),2));
plnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),3));
phemailtext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),4));}
     
     
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        userfnametext = new javax.swing.JTextField();
        userlnametext = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        sellerjtable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        updatesellerbutton = new javax.swing.JButton();
        JLastnameLabel = new javax.swing.JLabel();
        drugsbutton = new javax.swing.JButton();
        JFirstnameLabel = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        JIDLabel = new javax.swing.JLabel();
        orderbutton = new javax.swing.JButton();
        insertpharmacistbutton = new javax.swing.JButton();
        exitbutton = new javax.swing.JButton();
        pfnametext = new javax.swing.JTextField();
        plnametext = new javax.swing.JTextField();
        pemailtext = new javax.swing.JTextField();
        Juser_type_Label = new javax.swing.JLabel();
        useridtext = new javax.swing.JTextField();
        JFirstnameLabel1 = new javax.swing.JLabel();
        JLastnameLabel1 = new javax.swing.JLabel();
        JLastnameLabel2 = new javax.swing.JLabel();
        JFirstnameLabel2 = new javax.swing.JLabel();
        JIDLabel1 = new javax.swing.JLabel();
        phfnametext = new javax.swing.JTextField();
        phlnametext = new javax.swing.JTextField();
        phemailtext = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        pharmacistjtable = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        JPIDLabel = new javax.swing.JLabel();
        phidtext = new javax.swing.JTextField();
        c_userpassbutton = new javax.swing.JButton();
        c_passfromtext = new javax.swing.JTextField();
        c_passtotext = new javax.swing.JTextField();
        JFirstnameLabel4 = new javax.swing.JLabel();
        JFirstnameLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        userfnametext.setToolTipText("");

        jLabel3.setText("Seller Information");

        sellerjtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PID", "fname", "lname", "gain", "email"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        sellerjtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sellerjtableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(sellerjtable);

        jLabel4.setText("Pharmacist Information");

        jLabel1.setText("SELLERS");

        updatesellerbutton.setText("Update");
        updatesellerbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatesellerbuttonActionPerformed(evt);
            }
        });

        JLastnameLabel.setText("fname");
        JLastnameLabel.setToolTipText("");

        drugsbutton.setText("DRUGS");
        drugsbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drugsbuttonActionPerformed(evt);
            }
        });

        JFirstnameLabel.setText("llname");

        jLabel5.setText("HEAD TO");

        JIDLabel.setText("email");

        orderbutton.setText("ORDERS");
        orderbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderbuttonActionPerformed(evt);
            }
        });

        insertpharmacistbutton.setText("Insert");
        insertpharmacistbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertpharmacistbuttonActionPerformed(evt);
            }
        });

        exitbutton.setText("Exit");
        exitbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbuttonActionPerformed(evt);
            }
        });

        pfnametext.setToolTipText("");

        pemailtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pemailtextActionPerformed(evt);
            }
        });

        Juser_type_Label.setText("SELLER");

        useridtext.setEditable(false);
        useridtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                useridtextActionPerformed(evt);
            }
        });

        JFirstnameLabel1.setText("lname");

        JLastnameLabel1.setText("fname");
        JLastnameLabel1.setToolTipText("");

        JLastnameLabel2.setText("fname");
        JLastnameLabel2.setToolTipText("");

        JFirstnameLabel2.setText("llname");

        JIDLabel1.setText("email");

        phfnametext.setToolTipText("");

        phemailtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phemailtextActionPerformed(evt);
            }
        });

        pharmacistjtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PHID", "fname", "lname", "email"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        pharmacistjtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pharmacistjtableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(pharmacistjtable);

        jLabel2.setText("Pharmacists");

        JPIDLabel.setText("PHID");

        phidtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phidtextActionPerformed(evt);
            }
        });

        c_userpassbutton.setText("ChangePassword");
        c_userpassbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_userpassbuttonActionPerformed(evt);
            }
        });

        JFirstnameLabel4.setText("Change_To");

        JFirstnameLabel3.setText("CurrentPassword");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Juser_type_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addComponent(JLastnameLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(JFirstnameLabel1)
                        .addGap(18, 18, Short.MAX_VALUE)))
                .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JFirstnameLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(JFirstnameLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(c_passtotext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(c_passfromtext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c_userpassbutton)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(182, 182, 182)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(drugsbutton)
                    .addComponent(orderbutton))
                .addGap(72, 72, 72))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(exitbutton))
                    .addComponent(jLabel2)))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(updatesellerbutton)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(JIDLabel)
                        .addGap(24, 24, 24)
                        .addComponent(pemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JLastnameLabel)
                            .addComponent(JFirstnameLabel))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(plnametext, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(pfnametext)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JLastnameLabel2)
                            .addComponent(JFirstnameLabel2)
                            .addComponent(JIDLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(phemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(phfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(phlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(JPIDLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(phidtext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)))
                .addComponent(insertpharmacistbutton)
                .addGap(291, 291, 291))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(c_passfromtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c_userpassbutton)
                            .addComponent(JFirstnameLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(c_passtotext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JFirstnameLabel4))
                        .addGap(52, 52, 52)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(drugsbutton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(orderbutton))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Juser_type_Label)
                                    .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(JLastnameLabel1)
                                .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(JFirstnameLabel1)
                                .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(JPIDLabel)
                                .addComponent(phidtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(insertpharmacistbutton)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(106, 106, 106)
                                .addComponent(updatesellerbutton))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JLastnameLabel)
                                    .addComponent(pfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(JFirstnameLabel)
                                            .addComponent(plnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(pemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JIDLabel)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(JLastnameLabel2)
                                            .addComponent(phfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(JFirstnameLabel2)
                                            .addComponent(phlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(phemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JIDLabel1))))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(exitbutton))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void updatesellerbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatesellerbuttonActionPerformed
        // TODO add your handling code here:
        updateSellerAction();loadsellerinfo(idvar3, passvar3);loadsellers();
    }//GEN-LAST:event_updatesellerbuttonActionPerformed

    private void drugsbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drugsbuttonActionPerformed
        // TODO add your handling code here:
        new admindrugsjdialog2((connectloginjframe) SwingUtilities.getWindowAncestor(this),true,idvar3,passvar3,Juser_type_Label.getText()).setVisible(true);
    }//GEN-LAST:event_drugsbuttonActionPerformed

    private void orderbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderbuttonActionPerformed
        // TODO add your handling code here:
        new orderjdialog((connectloginjframe) SwingUtilities.getWindowAncestor(this),true,idvar3,passvar3,Juser_type_Label.getText()).setVisible(true);
    }//GEN-LAST:event_orderbuttonActionPerformed

    private void insertpharmacistbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertpharmacistbuttonActionPerformed
        // TODO add your handling code here:
        insertPharmacistAction();loadpharmacists();

    }//GEN-LAST:event_insertpharmacistbuttonActionPerformed

    private void exitbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbuttonActionPerformed
        // TODO add your handling code here:

        exitAction();
    }//GEN-LAST:event_exitbuttonActionPerformed

    private void pemailtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pemailtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pemailtextActionPerformed

    private void useridtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_useridtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_useridtextActionPerformed

    private void phemailtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phemailtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phemailtextActionPerformed

    private void phidtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phidtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phidtextActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // TODO add your handling code here:
        loadpharmacists();loadsellers();
    }//GEN-LAST:event_formComponentShown

    private void c_userpassbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_userpassbuttonActionPerformed
        // TODO add your handling code here:
        executeStoredProcedure();
    }//GEN-LAST:event_c_userpassbuttonActionPerformed

    private void sellerjtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sellerjtableMouseClicked
        // TODO add your handling code here:
        STableMouseClickedAction();
    }//GEN-LAST:event_sellerjtableMouseClicked

    private void pharmacistjtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pharmacistjtableMouseClicked
        // TODO add your handling code here:
        PhTableMouseClickedAction();
    }//GEN-LAST:event_pharmacistjtableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(sellerjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(sellerjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(sellerjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(sellerjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                sellerjdialog dialog = new sellerjdialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JFirstnameLabel;
    private javax.swing.JLabel JFirstnameLabel1;
    private javax.swing.JLabel JFirstnameLabel2;
    private javax.swing.JLabel JFirstnameLabel3;
    private javax.swing.JLabel JFirstnameLabel4;
    private javax.swing.JLabel JIDLabel;
    private javax.swing.JLabel JIDLabel1;
    private javax.swing.JLabel JLastnameLabel;
    private javax.swing.JLabel JLastnameLabel1;
    private javax.swing.JLabel JLastnameLabel2;
    private javax.swing.JLabel JPIDLabel;
    private javax.swing.JLabel Juser_type_Label;
    private javax.swing.JTextField c_passfromtext;
    private javax.swing.JTextField c_passtotext;
    private javax.swing.JButton c_userpassbutton;
    private javax.swing.JButton drugsbutton;
    private javax.swing.JButton exitbutton;
    private javax.swing.JButton insertpharmacistbutton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton orderbutton;
    private javax.swing.JTextField pemailtext;
    private javax.swing.JTextField pfnametext;
    private javax.swing.JTable pharmacistjtable;
    private javax.swing.JTextField phemailtext;
    private javax.swing.JTextField phfnametext;
    private javax.swing.JTextField phidtext;
    private javax.swing.JTextField phlnametext;
    private javax.swing.JTextField plnametext;
    private javax.swing.JTable sellerjtable;
    private javax.swing.JButton updatesellerbutton;
    private javax.swing.JTextField userfnametext;
    private javax.swing.JTextField useridtext;
    private javax.swing.JTextField userlnametext;
    // End of variables declaration//GEN-END:variables
}
