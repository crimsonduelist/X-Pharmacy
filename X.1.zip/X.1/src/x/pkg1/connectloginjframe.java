/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package x.pkg1;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author WiZ14
 */
public class connectloginjframe extends javax.swing.JFrame {
    /**
     * Creates new form connectloginform
     */
    public static Connection con1;
    private boolean connectbuttonpressed;
    
//private connectstring String="jdbc:oracle:thin:@127.0.0.1:1521:oracledb";


    public connectloginjframe() {
        //super(parent, modal);//this one is parent duh!
        connectbuttonpressed=false;
        initComponents();enableconnectbutton();
    }
    

    public String getusertypecombobox(){
        return String.valueOf(usertypecombobox.getSelectedItem());
    }
    public String getIdtext() {
        return idtext.getText();
    }
    public String getPasstext() {
        return passtext.getText();
    }
    public boolean getconnectbuttonpressed(){
        return connectbuttonpressed;
    }
    public void connectbuttonpressed(){
        connectbuttonpressed=true;
    }
public void exitAction(){
        connectbuttonpressed=false;
        this.dispose();
    }
public void enableconnectbutton(){
    if(this.idtext.getText().length()>0 && this.passtext.getText().length()>0){
    this.connectbutton.setEnabled(true);}
    else{this.connectbutton.setEnabled(false);}
}

public void disconnectaction(){
        try{con1.close();}
        catch(java.sql.SQLException e3){JOptionPane.showMessageDialog(this,e3.getMessage() );
}
    }

public void connectaction(){
    try{Class.forName("oracle.jdbc.driver.OracleDriver");
con1=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe","xaccess","pass");
}
catch(java.sql.SQLException exc1){
    javax.swing.JOptionPane.showMessageDialog(this,exc1.getMessage());
}
catch(Exception exc2){
    javax.swing.JOptionPane.showMessageDialog(this,exc2.getMessage());
}

    
}
public void which_one(CallableStatement statementvar){
//System.out.println(statementvar+"blablalb");
if(String.valueOf(usertypecombobox.getSelectedItem())=="ADMIN"){new adminjdialog2(this, true,idtext.getText(),passtext.getText()).setVisible(true);disconnectaction();System.out.println("disc");
}
            else if(String.valueOf(usertypecombobox.getSelectedItem())=="SELLER"){new sellerjdialog(this, true,idtext.getText(),passtext.getText()).setVisible(true);disconnectaction();System.out.println("disc");}
            else if(String.valueOf(usertypecombobox.getSelectedItem())=="PHARMACIST"){new pharmacistjdialog(this, true,idtext.getText(),passtext.getText()).setVisible(true);disconnectaction();System.out.println("disc");}    
}

public void executeStoredProcedure(){
    try(
            CallableStatement cstmt = con1.prepareCall("{call is_user(?,?,?,?)}");) {
        cstmt.setString("userid",getIdtext());
        cstmt.setString("passvar",getPasstext());
        cstmt.setString("usertype",String.valueOf(usertypecombobox.getSelectedItem()));
        cstmt.registerOutParameter ("is_userout", java.sql.Types.INTEGER);  
        cstmt.execute();  
        System.out.println("MANAGER ID: " + cstmt.getInt("is_userout"));
        
        if (cstmt.getInt("is_userout")==1){
            which_one(cstmt);
        
        }//System.out.println(cstmt+"asdfadsfa");
        cstmt.close();
    }
    catch( java.sql.SQLException exc5) {
             javax.swing.JOptionPane.showMessageDialog(this,exc5.getMessage());
        }
}

public void CHECKUSER() {
//String x = String.valueOf(usertypecombobox.getSelectedItem());
String query1="";
        System.out.println(query1);
        
        //java.sql.Statement callStmt;
        try {
            CallableStatement cs = con1.prepareCall("{call is_user(?,?,?,?)}");//("{call DMG.is_user("+"'"+getIdtext()+"',"+"'"+getPasstext()+"','s')}")
            cs.setString("userid","1");
            cs.setString("passvar","0000");
            cs.setString("usertype","ADMIN");
            cs.registerOutParameter ("is_userout", java.sql.Types.INTEGER);
            cs.execute();
            System.out.println(String.valueOf(usertypecombobox.getSelectedItem()));
            if (cs.getInt(4)==1){
                if (String.valueOf(usertypecombobox.getSelectedItem()) == "ADMIN"){System.out.println("sucess");}
                adminjdialog2 cd1=new adminjdialog2(this,true);
                cd1.setVisible(true);
                //if(cd1.getuserchoosedokflag()==false){return;}
                cs.close();
                    }
            
        }
        catch( java.sql.SQLException exc3) {
             javax.swing.JOptionPane.showMessageDialog(this,exc3.getMessage());
        }
        
    }



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        idlabel = new javax.swing.JLabel();
        passlabel = new javax.swing.JLabel();
        connectbutton = new javax.swing.JButton();
        exitbutton = new javax.swing.JButton();
        idtext = new javax.swing.JTextField();
        passtext = new javax.swing.JTextField();
        usertypecombobox = new javax.swing.JComboBox<>();
        testbutton2 = new javax.swing.JButton();
        testbutton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        idlabel.setText("ID");

        passlabel.setText("Pass");

        connectbutton.setText("Connect");
        connectbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                connectbuttonActionPerformed(evt);
            }
        });

        exitbutton.setText("Exit");
        exitbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbuttonActionPerformed(evt);
            }
        });

        idtext.setText("1");
        idtext.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                idtextCaretUpdate(evt);
            }
        });
        idtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idtextActionPerformed(evt);
            }
        });

        passtext.setText("0000");
        passtext.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                passtextCaretUpdate(evt);
            }
        });
        passtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passtextActionPerformed(evt);
            }
        });

        usertypecombobox.setMaximumRowCount(5);
        usertypecombobox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ADMIN", "SELLER", "PHARMACIST" }));
        usertypecombobox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usertypecomboboxActionPerformed(evt);
            }
        });

        testbutton2.setText("test");
        testbutton2.setEnabled(false);
        testbutton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                testbutton2ActionPerformed(evt);
            }
        });

        testbutton1.setText("test");
        testbutton1.setEnabled(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(idtext, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addComponent(passtext, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addComponent(idlabel)
                        .addGap(133, 133, 133)
                        .addComponent(passlabel))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(connectbutton)))
                .addContainerGap(129, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(exitbutton)
                        .addGap(92, 92, 92))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(usertypecombobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(testbutton2)
                        .addGap(83, 83, 83))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(329, Short.MAX_VALUE)
                    .addComponent(testbutton1)
                    .addGap(20, 20, 20)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(passlabel))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(idlabel)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(passtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addComponent(usertypecombobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(connectbutton)
                .addGap(41, 41, 41)
                .addComponent(exitbutton)
                .addGap(39, 39, 39)
                .addComponent(testbutton2)
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(266, Short.MAX_VALUE)
                    .addComponent(testbutton1)
                    .addContainerGap()))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbuttonActionPerformed
        // TODO add your handling code here:
        
        exitAction();
    }//GEN-LAST:event_exitbuttonActionPerformed

    private void connectbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_connectbuttonActionPerformed
        // TODO add your handling code here:
        connectaction();
        executeStoredProcedure();
        
    }//GEN-LAST:event_connectbuttonActionPerformed

    private void idtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idtextActionPerformed

    private void idtextCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_idtextCaretUpdate
        // TODO add your handling code here:
        enableconnectbutton();
    }//GEN-LAST:event_idtextCaretUpdate

    private void passtextCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_passtextCaretUpdate
        // TODO add your handling code here:
        enableconnectbutton();
    }//GEN-LAST:event_passtextCaretUpdate

    private void usertypecomboboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usertypecomboboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usertypecomboboxActionPerformed

    private void testbutton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_testbutton2ActionPerformed
        // TODO add your handling code here:
        executeStoredProcedure();
    }//GEN-LAST:event_testbutton2ActionPerformed

    private void passtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passtextActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(connectloginjframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(connectloginjframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(connectloginjframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(connectloginjframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new connectloginjframe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton connectbutton;
    private javax.swing.JButton exitbutton;
    private javax.swing.JLabel idlabel;
    private javax.swing.JTextField idtext;
    private javax.swing.JLabel passlabel;
    private javax.swing.JTextField passtext;
    private javax.swing.JButton testbutton1;
    private javax.swing.JButton testbutton2;
    private javax.swing.JComboBox<String> usertypecombobox;
    // End of variables declaration//GEN-END:variables
}
