/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package x.pkg1;

import java.awt.print.PrinterException;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author WiZ14
 */
public class adminjdialog2 extends javax.swing.JDialog {
public String idvar3;
public String passvar3;
    /**
     * Creates new form TrapeziJDialog
     */
    public adminjdialog2(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    public adminjdialog2(java.awt.Frame parent, boolean modal,String idvar1,String passvar1) {
        super(parent, modal);
        initComponents();
        idvar3=idvar1;passvar3=passvar1;
        useridtext.setText(idvar1);
        loadadmininfo(idvar1,passvar1);
       
        
    }
    public void loadadmininfo(String idvar2,String passvar2){
        
        String query5="SELECT FNAME,LNAME "
                + "FROM ADMIN "
                + " where aid='"+idvar2
                +"' AND PASS='"+passvar2+"'";
        System.out.println(query5);
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement();
                searchRS=searchStm.executeQuery(query5);
              // clearTable((javax.swing.table.DefaultTableModel)jMemberTable.getModel());
               if(searchRS.next()){
       //String s=searchRS.getString("FNAME");
       //String s2=searchRS.getString("LNAME");
       userfnametext.setText(searchRS.getString("FNAME"));
       userlnametext.setText(searchRS.getString("LNAME"));
               }
           

                   
               searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
    }
    public void insertsellerAction() {
String query1="INSERT INTO PVLHTHS(PID,AID,FNAME,LNAME,EMAIL) " +
                    "VALUES("+ 
                    "PSeq.NEXTVAL,"+"'"+useridtext.getText()+"',"+
                    "'"+pfnametext.getText()+"',"+
                    "'"+plnametext.getText()+"',"+
                    "'"+pemailtext.getText()+"')"
                    
                ;
        
        System.out.println(query1);
        
        java.sql.Statement insertStmt;
        try {
            insertStmt =  connectloginjframe.con1.createStatement();
            insertStmt.executeQuery(query1);
            insertStmt.close();
        }
        catch( java.sql.SQLException e4) {
             JOptionPane.showMessageDialog( this , e4.getMessage() );
        }
        
    }
    public void exitAction(){
        //connectbuttonpressed=false;
        this.dispose();
    }
    public void RESETSELLERAction() {
        String query2="UPDATE PVLHTHS "+
                "SET PASS='0000' "+
                "WHERE PID="+pidtext.getText();
                
System.out.println(query2);
        java.sql.Statement updateStm;
                try {
            updateStm =  connectloginjframe.con1.createStatement();
            updateStm.executeQuery(query2);
            updateStm.close();
        }
        catch( java.sql.SQLException e5) {
             JOptionPane.showMessageDialog( this , e5.getMessage() );
        }
    }
    public void RESETPHARMAAction() {
        String query2="UPDATE PHARMAKOPOIOS "
                +"SET PASS='0000' "
                +" WHERE PHID="+phidtext.getText();
                
System.out.println(query2);
        java.sql.Statement updateStm;
                try {
            updateStm =  connectloginjframe.con1.createStatement();
            updateStm.executeQuery(query2);
            updateStm.close();
        }
        catch( java.sql.SQLException e5) {
             JOptionPane.showMessageDialog( this , e5.getMessage() );
        }
    }
    
     public void deletesellerAction() {
        String query3="DELETE FROM PVLHTHS WHERE PID="+pidtext.getText();
             
                

        System.out.println(query3);

        java.sql.Statement deleteStm;
                try{deleteStm=connectloginjframe.con1.createStatement();
                deleteStm.executeQuery(query3);
                deleteStm.close();}
                catch(SQLException e6){
                    JOptionPane.showMessageDialog(this,e6.getMessage());}
        
        
    }
    public void deletepharmacistAction() {
        String query3="DELETE FROM PHARMAKOPOIOS WHERE PHID="+phidtext.getText();
             
                

        System.out.println(query3);

        java.sql.Statement deleteStm;
                try{deleteStm=connectloginjframe.con1.createStatement();
                deleteStm.executeQuery(query3);
                deleteStm.close();}
                catch(SQLException e6){
                    JOptionPane.showMessageDialog(this,e6.getMessage());}
        
        
    }
     public void clearTable(javax.swing.table.DefaultTableModel model){
         int numrows =model.getRowCount();
         for (int i =numrows-1;i>=0;i--){
             model.removeRow(i);
         }
     }
     public void loadsellers(){
        String query4="SELECT PID,FNAME,LNAME,GAIN,EMAIL "
                + "FROM PVLHTHS "
                + "ORDER BY GAIN DESC";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
               clearTable((javax.swing.table.DefaultTableModel)sellerjtable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) sellerjtable.getModel()).addRow(
        new Object[]{
           searchRS.getString("PID"),
           searchRS.getString("FNAME"),
           searchRS.getString("LNAME"),
           searchRS.getString("GAIN"),
           searchRS.getString("EMAIL")
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
     public void loadpharmacists(){
        String query4="SELECT PHID,FNAME,LNAME,EMAIL "
                + "FROM PHARMAKOPOIOS "
                + "ORDER BY PHID";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
               
               clearTable((javax.swing.table.DefaultTableModel)pharmacistjtable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) pharmacistjtable.getModel()).addRow(
        new Object[]{
           searchRS.getString("PHID"),
           searchRS.getString("FNAME"),
           searchRS.getString("LNAME"),
           searchRS.getString("EMAIL")
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
     
     public void loadsellersofphid(){
        String query4="SELECT PID,FNAME,LNAME,GAIN,EMAIL "
                + "FROM PVLHTHS WHERE PID=(SELECT PID FROM PHARMAKOPOIOS WHERE PHID="+phidtext.getText()+")";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
               clearTable((javax.swing.table.DefaultTableModel)sellerjtable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) sellerjtable.getModel()).addRow(
        new Object[]{
           searchRS.getString("PID"),
           searchRS.getString("FNAME"),
           searchRS.getString("LNAME"),
           searchRS.getString("GAIN"),
           searchRS.getString("EMAIL")
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
     public void loadpharmacistsofpid(){
        String query4="SELECT PHID,FNAME,LNAME,EMAIL "
                + "FROM PHARMAKOPOIOS "
                + "WHERE PHARMAKOPOIOS.PID="+pidtext.getText()+"";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
               
               clearTable((javax.swing.table.DefaultTableModel)pharmacistjtable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) pharmacistjtable.getModel()).addRow(
        new Object[]{
           searchRS.getString("PHID"),
           searchRS.getString("FNAME"),
           searchRS.getString("LNAME"),
           searchRS.getString("EMAIL")
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
     
     
     public void STableMouseClickedAction(){
        if((sellerjtable.getSelectedRow() )<0)return;
pidtext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),0));
pfnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),1));
plnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),2));
pemailtext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),5));}
  
     public void PhTableMouseClickedAction(){
        if((pharmacistjtable.getSelectedRow() )<0)return;
phidtext.setText(""+pharmacistjtable.getModel().getValueAt(pharmacistjtable.getSelectedRow(),0));}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        sellerjtable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        JPIDLabel = new javax.swing.JLabel();
        JLastnameLabel = new javax.swing.JLabel();
        JFirstnameLabel = new javax.swing.JLabel();
        JIDLabel = new javax.swing.JLabel();
        resetpharmapassbutton = new javax.swing.JButton();
        deletesellerbutton = new javax.swing.JButton();
        pidtext = new javax.swing.JTextField();
        pfnametext = new javax.swing.JTextField();
        plnametext = new javax.swing.JTextField();
        pemailtext = new javax.swing.JTextField();
        Juser_type_Label = new javax.swing.JLabel();
        useridtext = new javax.swing.JTextField();
        JFirstnameLabel1 = new javax.swing.JLabel();
        JLastnameLabel1 = new javax.swing.JLabel();
        userfnametext = new javax.swing.JTextField();
        userlnametext = new javax.swing.JTextField();
        JPIDLabel1 = new javax.swing.JLabel();
        phidtext = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        insertbutton = new javax.swing.JButton();
        resetsellerpassbutton = new javax.swing.JButton();
        drugsbutton = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        inventorybutton = new javax.swing.JButton();
        exitbutton = new javax.swing.JButton();
        deletepharmacistbutton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        pharmacistjtable = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        loadpharmacistsofpidbutton = new javax.swing.JButton();
        loadsellerofphidbutton = new javax.swing.JButton();
        loadallbutton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        sellerjtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PID", "fname", "lname", "gain", "email"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        sellerjtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sellerjtableMouseClicked(evt);
            }
        });
        sellerjtable.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                sellerjtableComponentShown(evt);
            }
        });
        jScrollPane1.setViewportView(sellerjtable);

        jLabel1.setText("SELLERS");

        JPIDLabel.setText("PID");

        JLastnameLabel.setText("fname");
        JLastnameLabel.setToolTipText("");

        JFirstnameLabel.setText("llname");

        JIDLabel.setText("email");

        resetpharmapassbutton.setText("ResetPass");
        resetpharmapassbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetpharmapassbuttonActionPerformed(evt);
            }
        });

        deletesellerbutton.setText("Delete");
        deletesellerbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletesellerbuttonActionPerformed(evt);
            }
        });

        pidtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pidtextActionPerformed(evt);
            }
        });

        pfnametext.setToolTipText("");

        pemailtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pemailtextActionPerformed(evt);
            }
        });

        Juser_type_Label.setText("ADMIN");

        useridtext.setEditable(false);
        useridtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                useridtextActionPerformed(evt);
            }
        });

        JFirstnameLabel1.setText("lname");

        JLastnameLabel1.setText("fname");
        JLastnameLabel1.setToolTipText("");

        userfnametext.setToolTipText("");

        JPIDLabel1.setText("PHID");

        phidtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phidtextActionPerformed(evt);
            }
        });

        jLabel3.setText("Seller Information");

        jLabel4.setText("Pharmacist Information");

        insertbutton.setText("Insert");
        insertbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertbuttonActionPerformed(evt);
            }
        });

        resetsellerpassbutton.setText("ResetPass");
        resetsellerpassbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetsellerpassbuttonActionPerformed(evt);
            }
        });

        drugsbutton.setText("DRUGS");
        drugsbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drugsbuttonActionPerformed(evt);
            }
        });

        jLabel5.setText("HEAD TO");

        inventorybutton.setText("INVENTORY");
        inventorybutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventorybuttonActionPerformed(evt);
            }
        });

        exitbutton.setText("Exit");
        exitbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbuttonActionPerformed(evt);
            }
        });

        deletepharmacistbutton.setText("Delete");
        deletepharmacistbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletepharmacistbuttonActionPerformed(evt);
            }
        });

        pharmacistjtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PHID", "fname", "lname", "email"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        pharmacistjtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pharmacistjtableMouseClicked(evt);
            }
        });
        pharmacistjtable.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                pharmacistjtableComponentShown(evt);
            }
        });
        jScrollPane2.setViewportView(pharmacistjtable);

        jLabel6.setText("Pharmacists");

        loadpharmacistsofpidbutton.setText("LoadPharmacists");
        loadpharmacistsofpidbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadpharmacistsofpidbuttonActionPerformed(evt);
            }
        });

        loadsellerofphidbutton.setText("LoadSellers");
        loadsellerofphidbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadsellerofphidbuttonActionPerformed(evt);
            }
        });

        loadallbutton.setText("LoadAll");
        loadallbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadallbuttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Juser_type_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addComponent(JLastnameLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(JFirstnameLabel1)
                        .addGap(18, 18, Short.MAX_VALUE)))
                .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(344, 344, 344))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(JPIDLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(pidtext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JLastnameLabel)
                                    .addComponent(JFirstnameLabel))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(plnametext)
                                    .addComponent(pfnametext))))
                        .addGap(63, 63, 63)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(JPIDLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(phidtext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(deletepharmacistbutton)
                                    .addComponent(resetpharmapassbutton)
                                    .addComponent(loadsellerofphidbutton)
                                    .addComponent(loadallbutton)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(JIDLabel)
                        .addGap(24, 24, 24)
                        .addComponent(pemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(drugsbutton)
                    .addComponent(inventorybutton))
                .addGap(72, 72, 72))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)))
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(exitbutton))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(loadpharmacistsofpidbutton)
                    .addComponent(resetsellerpassbutton)
                    .addComponent(insertbutton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(deletesellerbutton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Juser_type_Label)
                                    .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(JLastnameLabel1)
                                .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(JFirstnameLabel1)
                                .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JPIDLabel)
                            .addComponent(pidtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JPIDLabel1)
                            .addComponent(phidtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(resetpharmapassbutton))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JLastnameLabel)
                            .addComponent(pfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(deletepharmacistbutton))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JFirstnameLabel)
                            .addComponent(plnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(loadsellerofphidbutton)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(drugsbutton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(inventorybutton)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JIDLabel)
                        .addComponent(pemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(resetsellerpassbutton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(insertbutton)
                    .addComponent(loadallbutton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deletesellerbutton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loadpharmacistsofpidbutton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(exitbutton))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void deletesellerbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletesellerbuttonActionPerformed
        // TODO add your handling code here:
        deletesellerAction();loadsellers();
    }//GEN-LAST:event_deletesellerbuttonActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // TODO add your handling code here:
        //loadsellers();loadpharmacists();
    }//GEN-LAST:event_formComponentShown

    private void useridtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_useridtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_useridtextActionPerformed

    private void pidtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pidtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pidtextActionPerformed

    private void phidtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phidtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phidtextActionPerformed

    private void pemailtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pemailtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pemailtextActionPerformed

    private void insertbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertbuttonActionPerformed
        // TODO add your handling code here:
        insertsellerAction();loadsellers();
    }//GEN-LAST:event_insertbuttonActionPerformed

    private void resetsellerpassbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetsellerpassbuttonActionPerformed
        // TODO add your handling code here:
        RESETSELLERAction();
    }//GEN-LAST:event_resetsellerpassbuttonActionPerformed

    private void resetpharmapassbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetpharmapassbuttonActionPerformed
        // TODO add your handling code here:

        RESETPHARMAAction();
    }//GEN-LAST:event_resetpharmapassbuttonActionPerformed

    private void inventorybuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventorybuttonActionPerformed
        // TODO add your handling code here:
        new admininventoryjdialog((connectloginjframe) SwingUtilities.getWindowAncestor(this),true,idvar3,passvar3).setVisible(true);
    }//GEN-LAST:event_inventorybuttonActionPerformed

    private void drugsbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drugsbuttonActionPerformed
        // TODO add your handling code here:
        new admindrugsjdialog2((connectloginjframe) SwingUtilities.getWindowAncestor(this),true,idvar3,passvar3,Juser_type_Label.getText()).setVisible(true);
    }//GEN-LAST:event_drugsbuttonActionPerformed

    private void exitbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbuttonActionPerformed
        // TODO add your handling code here:

        exitAction();
    }//GEN-LAST:event_exitbuttonActionPerformed

    private void deletepharmacistbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletepharmacistbuttonActionPerformed
        // TODO add your handling code here:
        deletepharmacistAction();loadpharmacists();
    }//GEN-LAST:event_deletepharmacistbuttonActionPerformed

    private void sellerjtableComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_sellerjtableComponentShown
        // TODO add your handling code here:
        loadsellers();loadpharmacists();
    }//GEN-LAST:event_sellerjtableComponentShown

    private void pharmacistjtableComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_pharmacistjtableComponentShown
        // TODO add your handling code here:
        loadsellers();loadpharmacists();
    }//GEN-LAST:event_pharmacistjtableComponentShown

    private void pharmacistjtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pharmacistjtableMouseClicked
        // TODO add your handling code here:
        PhTableMouseClickedAction();
    }//GEN-LAST:event_pharmacistjtableMouseClicked

    private void sellerjtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sellerjtableMouseClicked
        // TODO add your handling code here:
        STableMouseClickedAction();
    }//GEN-LAST:event_sellerjtableMouseClicked

    private void loadallbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadallbuttonActionPerformed
        // TODO add your handling code here:
        loadsellers();loadpharmacists();
    }//GEN-LAST:event_loadallbuttonActionPerformed

    private void loadpharmacistsofpidbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadpharmacistsofpidbuttonActionPerformed
        // TODO add your handling code here:
        loadpharmacistsofpid();
    }//GEN-LAST:event_loadpharmacistsofpidbuttonActionPerformed

    private void loadsellerofphidbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadsellerofphidbuttonActionPerformed
        // TODO add your handling code here:
        loadsellersofphid();
    }//GEN-LAST:event_loadsellerofphidbuttonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(adminjdialog2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(adminjdialog2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(adminjdialog2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(adminjdialog2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                adminjdialog2 dialog = new adminjdialog2(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JFirstnameLabel;
    private javax.swing.JLabel JFirstnameLabel1;
    private javax.swing.JLabel JIDLabel;
    private javax.swing.JLabel JLastnameLabel;
    private javax.swing.JLabel JLastnameLabel1;
    private javax.swing.JLabel JPIDLabel;
    private javax.swing.JLabel JPIDLabel1;
    private javax.swing.JLabel Juser_type_Label;
    private javax.swing.JButton deletepharmacistbutton;
    private javax.swing.JButton deletesellerbutton;
    private javax.swing.JButton drugsbutton;
    private javax.swing.JButton exitbutton;
    private javax.swing.JButton insertbutton;
    private javax.swing.JButton inventorybutton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton loadallbutton;
    private javax.swing.JButton loadpharmacistsofpidbutton;
    private javax.swing.JButton loadsellerofphidbutton;
    private javax.swing.JTextField pemailtext;
    private javax.swing.JTextField pfnametext;
    private javax.swing.JTable pharmacistjtable;
    private javax.swing.JTextField phidtext;
    private javax.swing.JTextField pidtext;
    private javax.swing.JTextField plnametext;
    private javax.swing.JButton resetpharmapassbutton;
    private javax.swing.JButton resetsellerpassbutton;
    private javax.swing.JTable sellerjtable;
    private javax.swing.JTextField userfnametext;
    private javax.swing.JTextField useridtext;
    private javax.swing.JTextField userlnametext;
    // End of variables declaration//GEN-END:variables
}
