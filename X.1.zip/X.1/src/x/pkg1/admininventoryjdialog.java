/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package x.pkg1;

import java.util.Date;
import java.util.*;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static x.pkg1.connectloginjframe.con1;


/**
 *
 * @author WiZ14
 */
public class admininventoryjdialog extends javax.swing.JDialog {
public String idvar5;
public String passvar5;
    /**
     * Creates new form admininventoryjdialog
     */
    public admininventoryjdialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    public admininventoryjdialog(java.awt.Frame parent, boolean modal,String idvar1,String passvar1) {
        super(parent, modal);
        initComponents();
        adminidtext.setText(idvar1);idvar5=idvar1;
        loadadmininfo(idvar1,passvar1);
       
        
    }
    public void loadadmininfo(String idvar2,String passvar2){
        
        String query5="SELECT FNAME,LNAME "
                + "FROM ADMIN "
                + " where aid='"+idvar2
                +"' AND PASS='"+passvar2+"'";
        System.out.println(query5);
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement();
                searchRS=searchStm.executeQuery(query5);
              // clearTable((javax.swing.table.DefaultTableModel)jMemberTable.getModel());
               if(searchRS.next()){
       //String s=searchRS.getString("FNAME");
       //String s2=searchRS.getString("LNAME");
       adminfnametext.setText(searchRS.getString("FNAME"));
       adminlnametext.setText(searchRS.getString("LNAME"));
               }
           

                   
               searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
    }
    /*public void insertInventoryAction2(){
        String query5="BEGIN\n" +
"\n" +
"add_quant_toinv('1',TO_DATE('29/9/2029','DD/MM/YY HH:MI:SS'),33,'1',1);\n" +
"\n" +
"\n" +
"end;\n" +
"/"
                + "\n";
        System.out.println(query5);

                try{
                    CallableStatement cstmt = con1.prepareCall(query5);
                    cstmt.execute();
                }
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
    }*/
    public void insertInventoryAction(){
//(sdf.parse(iexdatetext.getText())

try{
//String myDate="20-09-29";
/*SimpleDateFormat sdf=new SimpleDateFormat("DD-MM-YY");
Date date=sdf.parse(myDate);
Timestamp d=new java.sql.Timestamp(date.getTime());*/

   //int VV=Integer.valueOf(iquanttext.getText());
    CallableStatement cstmt = con1.prepareCall("{call add_quant_toinv("+
            dcodetext.getText()+",TO_DATE('"+iexdatetext.getText()+"','DD/MM/YYYY HH:MI:SS'),"+ //*using YYYY here
            purchasedcosttext.getText()+","+adminidtext.getText()+","+iquanttext.getText()+")}");//add_quant_toinv('1',TO_DATE('29/9/2029','DD/MM/YY HH:MI:SS'),33,'1',1);
//java.sql.Timestamp d=new java.sql.Timestamp((date).getTime());
        /*cstmt.setString("dcode",dcodetext.getText());
        cstmt.setString("iexdate","TO_CHAR('29/9/2029','DD/MM/YYYY')");
        cstmt.setInt("purchasedcost",1);
        cstmt.setString("aid","1");
        cstmt.setInt("quantin",1);*/
        cstmt.execute();
            System.out.println(cstmt);cstmt.close();
            
}
        catch( java.sql.SQLException e4) {
             JOptionPane.showMessageDialog( this , e4.getMessage() );
        }



        
        
        
    }
   
    public void deleteInventoryAction2(){
        try{
            java.util.Date utilDate = new SimpleDateFormat("DD/MM/YYYY HH:MI:SS").parse(iexdatetext.getText());
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
        CallableStatement cstmt = con1.prepareCall("{call sub_quant_frominv(?,?,?,?,?)}");
//sub_quant_frominv('1',TO_DATE('29/9/29','DD/MM/YYYY HH:MI:SS'),33,'1',1);
        cstmt.setString(1,dcodetext.getText());
        cstmt.setDate(2,sqlDate);
        cstmt.setString(3,purchasedcosttext.getText());
        cstmt.setString(4,aidtext.getText());
        cstmt.setString(5,iquanttext.getText());
        cstmt.execute();
            System.out.println(cstmt);cstmt.close();
        }
        catch( java.sql.SQLException e4) {
             JOptionPane.showMessageDialog( this , e4.getMessage() );
        } 
        catch (ParseException ex) {
        Logger.getLogger(admininventoryjdialog.class.getName()).log(Level.SEVERE, null, ex);
        //e.printStackTrace();
    }
    }
    
    
    
     public void deleteInventoryAction() {
        try{ 
        CallableStatement cstmt = con1.prepareCall("{call sub_quant_frominv("+
                dcodetext.getText()
                +",TO_DATE('"+iexdatetext.getText()+"','DD/MM/YY HH:MI:SS'),"   //*and YY HERE MAKES all the difference
                +purchasedcosttext.getText()+","
                +aidtext.getText()+","+iquanttext.getText()+")}");
//sub_quant_frominv('1',TO_DATE('29/9/29','DD/MM/YYYY HH:MI:SS'),33,'1',1);
        cstmt.execute();
            System.out.println(cstmt);cstmt.close();
        }
        catch( java.sql.SQLException e4) {
             JOptionPane.showMessageDialog( this , e4.getMessage() );
        }
     }
     
     public void clearTable(javax.swing.table.DefaultTableModel model){
         int numrows =model.getRowCount();
         for (int i =numrows-1;i>=0;i--){
             model.removeRow(i);
         }
     }
     
     public void loaddrugs(){
        clearTable((javax.swing.table.DefaultTableModel)inventorytable.getModel());
         String query4="SELECT icode,dcode,iexdate,purchasedcost,aid "
                + "FROM INVENTORY "
                + "ORDER BY icode DESC";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
              //clearTable((javax.swing.table.DefaultTableModel)inventorytable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) inventorytable.getModel()).addRow(
        new Object[]{
           searchRS.getString("icode"),
           searchRS.getString("dcode"),
           searchRS.getString("iexdate"),
           searchRS.getString("purchasedcost"),
           searchRS.getString("aid")
           
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
     
    public void TableMouseClickedAction(){
        if((inventorytable.getSelectedRow() )<0)return;
dcodetext.setText(""+inventorytable.getModel().getValueAt(inventorytable.getSelectedRow(),1));
iexdatetext.setText(""+inventorytable.getModel().getValueAt(inventorytable.getSelectedRow(),2));
purchasedcosttext.setText(""+inventorytable.getModel().getValueAt(inventorytable.getSelectedRow(),3));
aidtext.setText(""+inventorytable.getModel().getValueAt(inventorytable.getSelectedRow(),4));}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        insertbutton = new javax.swing.JButton();
        JFirstnameLabel = new javax.swing.JLabel();
        backbutton = new javax.swing.JButton();
        JRegdateLabel = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        JIDLabel = new javax.swing.JLabel();
        deletebutton = new javax.swing.JButton();
        dcodetext = new javax.swing.JTextField();
        iexdatetext = new javax.swing.JTextField();
        purchasedcosttext = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        inventorytable = new javax.swing.JTable();
        aidtext = new javax.swing.JTextField();
        iquanttext = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        JPIDLabel = new javax.swing.JLabel();
        JLastnameLabel = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        adminidtext = new javax.swing.JTextField();
        JFirstnameLabel1 = new javax.swing.JLabel();
        JLastnameLabel1 = new javax.swing.JLabel();
        adminfnametext = new javax.swing.JTextField();
        adminlnametext = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        insertbutton.setText("Insert");
        insertbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertbuttonActionPerformed(evt);
            }
        });

        JFirstnameLabel.setText("purchase_cost");

        backbutton.setText("back");
        backbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbuttonActionPerformed(evt);
            }
        });

        JRegdateLabel.setText("entry_admin_id");

        jLabel5.setText("HEAD TO:");

        JIDLabel.setText("AT_QUANTITY");

        deletebutton.setText("Delete");
        deletebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebuttonActionPerformed(evt);
            }
        });

        dcodetext.setText("1");
        dcodetext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dcodetextActionPerformed(evt);
            }
        });

        iexdatetext.setText("29/02/28");
        iexdatetext.setToolTipText("");
        iexdatetext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iexdatetextActionPerformed(evt);
            }
        });

        purchasedcosttext.setText("15");

        inventorytable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "icode", "dcode", "expiration_date", "purchase_cost", "entry_admin_id"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        inventorytable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inventorytableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(inventorytable);

        aidtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aidtextActionPerformed(evt);
            }
        });

        iquanttext.setText("1");
        iquanttext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iquanttextActionPerformed(evt);
            }
        });

        jLabel1.setText("INVENTORY");

        JPIDLabel.setText("dcode");

        JLastnameLabel.setText("expiration_date");
        JLastnameLabel.setToolTipText("");

        jLabel2.setText("ADMIN");

        adminidtext.setEditable(false);
        adminidtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminidtextActionPerformed(evt);
            }
        });

        JFirstnameLabel1.setText("lname");

        JLastnameLabel1.setText("fname");
        JLastnameLabel1.setToolTipText("");

        adminfnametext.setEditable(false);
        adminfnametext.setToolTipText("");

        adminlnametext.setEditable(false);

        jLabel3.setText("Inventory Information");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JLastnameLabel)
                                    .addComponent(JFirstnameLabel)
                                    .addComponent(JPIDLabel))
                                .addGap(22, 22, 22)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dcodetext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(iexdatetext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(purchasedcosttext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(backbutton))))
                .addGap(94, 94, 94))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(adminidtext, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(97, 97, 97)
                                .addComponent(JLastnameLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(adminfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(JFirstnameLabel1)
                                .addGap(18, 18, Short.MAX_VALUE)))
                        .addComponent(adminlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(JRegdateLabel)
                        .addGap(22, 22, 22)
                        .addComponent(aidtext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(deletebutton)
                            .addComponent(insertbutton))
                        .addGap(24, 24, 24))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(JIDLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(iquanttext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)))
                .addGap(344, 344, 344))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(adminidtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(40, 40, 40)
                                .addComponent(jLabel3))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(JLastnameLabel1)
                                .addComponent(adminfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(JFirstnameLabel1)
                                .addComponent(adminlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JIDLabel)
                                    .addComponent(iquanttext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(insertbutton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deletebutton))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JPIDLabel)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(dcodetext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(iexdatetext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JLastnameLabel))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(purchasedcosttext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(JFirstnameLabel))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JRegdateLabel)
                                    .addComponent(aidtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(backbutton)))
                .addGap(120, 120, 120)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void insertbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertbuttonActionPerformed
        // TODO add your handling code here:
        loaddrugs();insertInventoryAction();loaddrugs();
    }//GEN-LAST:event_insertbuttonActionPerformed

    private void backbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbuttonActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_backbuttonActionPerformed

    private void deletebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebuttonActionPerformed
        // TODO add your handling code here:
        loaddrugs();deleteInventoryAction();loaddrugs();
    }//GEN-LAST:event_deletebuttonActionPerformed

    private void dcodetextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dcodetextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dcodetextActionPerformed

    private void aidtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aidtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_aidtextActionPerformed

    private void adminidtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminidtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminidtextActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // TODO add your handling code here:
        loaddrugs();
    }//GEN-LAST:event_formComponentShown

    private void iquanttextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iquanttextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iquanttextActionPerformed

    private void iexdatetextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iexdatetextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iexdatetextActionPerformed

    private void inventorytableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inventorytableMouseClicked
        // TODO add your handling code here:
        TableMouseClickedAction();
    }//GEN-LAST:event_inventorytableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admininventoryjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admininventoryjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admininventoryjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admininventoryjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                admininventoryjdialog dialog = new admininventoryjdialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JFirstnameLabel;
    private javax.swing.JLabel JFirstnameLabel1;
    private javax.swing.JLabel JIDLabel;
    private javax.swing.JLabel JLastnameLabel;
    private javax.swing.JLabel JLastnameLabel1;
    private javax.swing.JLabel JPIDLabel;
    private javax.swing.JLabel JRegdateLabel;
    private javax.swing.JTextField adminfnametext;
    private javax.swing.JTextField adminidtext;
    private javax.swing.JTextField adminlnametext;
    private javax.swing.JTextField aidtext;
    private javax.swing.JButton backbutton;
    private javax.swing.JTextField dcodetext;
    private javax.swing.JButton deletebutton;
    private javax.swing.JTextField iexdatetext;
    private javax.swing.JButton insertbutton;
    private javax.swing.JTable inventorytable;
    private javax.swing.JTextField iquanttext;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField purchasedcosttext;
    // End of variables declaration//GEN-END:variables
}
