/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package x.pkg1;

import java.sql.CallableStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import static x.pkg1.connectloginjframe.con1;

/**
 *
 * @author WiZ14
 */
public class pharmacistjdialog extends javax.swing.JDialog {
public String idvar3;
public String passvar3;
    /**
     * Creates new form pharmacistjdialog
     */
    public pharmacistjdialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    
    public pharmacistjdialog(java.awt.Frame parent, boolean modal,String idvar1,String passvar1) {
        super(parent, modal);
        initComponents();
        idvar3=idvar1;passvar3=passvar1;
        useridtext.setText(idvar1);
        loaduserinfo(idvar1,passvar1);
       
        
    }
    
    public void executeStoredProcedure(){
    try(
            CallableStatement cstmt = con1.prepareCall("{call is_user(?,?,?,?)}");) {
        cstmt.setString("userid",idvar3);
        cstmt.setString("passvar",passvar3);
        cstmt.setString("usertype",Juser_type_Label.getText());
        cstmt.registerOutParameter ("is_userout", java.sql.Types.INTEGER);  
        cstmt.execute();  
        System.out.println("MANAGER ID: " + cstmt.getInt("is_userout"));
        
        if (cstmt.getInt("is_userout")==1){
            c_userpassAction();
        
        }//System.out.println(cstmt+"asdfadsfa");
        cstmt.close();
    }
    catch( java.sql.SQLException exc5) {
             javax.swing.JOptionPane.showMessageDialog(this,exc5.getMessage());
        }
}
    public void c_userpassAction(){
        String query2="UPDATE PHARMAKOPOIOS "+
                "SET PASS='"+c_passtotext.getText()+"' "+
                "WHERE PHID='"+useridtext.getText()+"'";
                
System.out.println(query2);
        java.sql.Statement updateStm;
                try {
            updateStm =  connectloginjframe.con1.createStatement();
            updateStm.executeQuery(query2);
            updateStm.close();
            exitAction();
        }
        catch( java.sql.SQLException e5) {
             JOptionPane.showMessageDialog( this , e5.getMessage() );
        }
    }
    
    
    
    public void loaduserinfo(String idvar2,String passvar2){
        
        String query5="SELECT FNAME,LNAME "
                + "FROM PHARMAKOPOIOS "
                + " where PID='"+idvar2
                +"' AND PASS='"+passvar2+"'";
        System.out.println(query5);
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement();
                searchRS=searchStm.executeQuery(query5);
              // clearTable((javax.swing.table.DefaultTableModel)jMemberTable.getModel());
               if(searchRS.next()){
       //String s=searchRS.getString("FNAME");
       //String s2=searchRS.getString("LNAME");
       userfnametext.setText(searchRS.getString("FNAME"));
       userlnametext.setText(searchRS.getString("LNAME"));
               }
           

                   
               searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
    }
    public void loadsellers(){
        String query4="SELECT PID,FNAME,LNAME,EMAIL "
                + "FROM PHARMAKOPOIOS WHERE PHID='"+useridtext.getText()+"'";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
               clearTable((javax.swing.table.DefaultTableModel)sellerjtable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) sellerjtable.getModel()).addRow(
        new Object[]{
           searchRS.getString("PID"),
           searchRS.getString("FNAME"),
           searchRS.getString("LNAME"),
           searchRS.getString("EMAIL")
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
    
    public void loadpharmacists(){
        String query4="SELECT PHID,FNAME,LNAME,EMAIL "
                + "FROM PHARMAKOPOIOS "
                + "WHERE PHARMAKOPOIOS.PHID='"+useridtext.getText()+"'";
     
        
        java.sql.Statement searchStm;
        java.sql.ResultSet searchRS;
                try{
                    searchStm=connectloginjframe.con1.createStatement(
                        java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE,
                        java.sql.ResultSet.CONCUR_READ_ONLY);
                searchRS=searchStm.executeQuery(query4);
               
               clearTable((javax.swing.table.DefaultTableModel)pharmacistjtable.getModel());
                while(searchRS.next()){
       ((javax.swing.table.DefaultTableModel) pharmacistjtable.getModel()).addRow(
        new Object[]{
           searchRS.getString("PHID"),
           searchRS.getString("FNAME"),
           searchRS.getString("LNAME"),
           searchRS.getString("EMAIL")
       });
                   
               }searchRS.close();
                searchStm.close();}
                catch(SQLException e7){
                    JOptionPane.showMessageDialog(this,e7.getMessage());}
        }
    
    public void clearTable(javax.swing.table.DefaultTableModel model){
         int numrows =model.getRowCount();
         for (int i =numrows-1;i>=0;i--){
             model.removeRow(i);
         }
     }
    
    public void exitAction(){
        //connectbuttonpressed=false;
        this.dispose();
    }
    
    public void updatePharmacistAction() {
        String query2="UPDATE PVLHTHS "+
                "SET FNAME='"+pfnametext.getText()+"',"+
                "LNAME='"+plnametext.getText()+"',"+
                "EMAIL='"+pemailtext.getText()+"',"+
                "WHERE PID='"+useridtext.getText()+"'";
                
System.out.println(query2);
        java.sql.Statement updateStm;
                try {
            updateStm =  connectloginjframe.con1.createStatement();
            updateStm.executeQuery(query2);
            updateStm.close();
        }
        catch( java.sql.SQLException e5) {
             JOptionPane.showMessageDialog( this , e5.getMessage() );
        }
    }
    
public void STableMouseClickedAction(){
        if((sellerjtable.getSelectedRow() )<0)return;
pidtext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),0));
pfnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),1));
plnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),2));
pemailtext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),3));}
  
     public void PhTableMouseClickedAction(){
        if((pharmacistjtable.getSelectedRow() )<0)return;
phfnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),1));
phlnametext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),3));
phemailtext.setText(""+sellerjtable.getModel().getValueAt(sellerjtable.getSelectedRow(),4));}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        JPIDLabel = new javax.swing.JLabel();
        JLastnameLabel = new javax.swing.JLabel();
        drugsbutton = new javax.swing.JButton();
        JFirstnameLabel = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        JIDLabel = new javax.swing.JLabel();
        orderbutton = new javax.swing.JButton();
        exitbutton = new javax.swing.JButton();
        userfnametext = new javax.swing.JTextField();
        userlnametext = new javax.swing.JTextField();
        pidtext = new javax.swing.JTextField();
        pfnametext = new javax.swing.JTextField();
        plnametext = new javax.swing.JTextField();
        pemailtext = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        Juser_type_Label = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        sellerjtable = new javax.swing.JTable();
        useridtext = new javax.swing.JTextField();
        JFirstnameLabel1 = new javax.swing.JLabel();
        JLastnameLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        pharmacistjtable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        JLastnameLabel2 = new javax.swing.JLabel();
        JFirstnameLabel2 = new javax.swing.JLabel();
        JIDLabel1 = new javax.swing.JLabel();
        phfnametext = new javax.swing.JTextField();
        phlnametext = new javax.swing.JTextField();
        phemailtext = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        updatebutton = new javax.swing.JButton();
        c_passfromtext = new javax.swing.JTextField();
        c_passtotext = new javax.swing.JTextField();
        c_userpassbutton = new javax.swing.JButton();
        JFirstnameLabel3 = new javax.swing.JLabel();
        JFirstnameLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jLabel1.setText("SELLERS");

        JPIDLabel.setText("PID");

        JLastnameLabel.setText("fname");
        JLastnameLabel.setToolTipText("");

        drugsbutton.setText("DRUGS");
        drugsbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drugsbuttonActionPerformed(evt);
            }
        });

        JFirstnameLabel.setText("llname");

        jLabel5.setText("HEAD TO");

        JIDLabel.setText("email");

        orderbutton.setText("ORDERS");
        orderbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderbuttonActionPerformed(evt);
            }
        });

        exitbutton.setText("Exit");
        exitbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbuttonActionPerformed(evt);
            }
        });

        userfnametext.setToolTipText("");

        pidtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pidtextActionPerformed(evt);
            }
        });

        pfnametext.setToolTipText("");

        pemailtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pemailtextActionPerformed(evt);
            }
        });

        jLabel3.setText("Seller Information");

        Juser_type_Label.setText("PHARMACIST");

        sellerjtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PID", "fname", "lname", "email"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        sellerjtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sellerjtableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(sellerjtable);

        useridtext.setEditable(false);
        useridtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                useridtextActionPerformed(evt);
            }
        });

        JFirstnameLabel1.setText("lname");

        JLastnameLabel1.setText("fname");
        JLastnameLabel1.setToolTipText("");

        pharmacistjtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PID", "fname", "lname", "email"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        pharmacistjtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pharmacistjtableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(pharmacistjtable);

        jLabel4.setText("Pharmacists");

        JLastnameLabel2.setText("fname");
        JLastnameLabel2.setToolTipText("");

        JFirstnameLabel2.setText("llname");

        JIDLabel1.setText("email");

        phfnametext.setToolTipText("");

        phemailtext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phemailtextActionPerformed(evt);
            }
        });

        jLabel6.setText("Pharmacist Information");

        updatebutton.setText("Update");
        updatebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebuttonActionPerformed(evt);
            }
        });

        c_userpassbutton.setText("ChangePassword");
        c_userpassbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_userpassbuttonActionPerformed(evt);
            }
        });

        JFirstnameLabel3.setText("CurrentPassword");

        JFirstnameLabel4.setText("Change_To");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(JIDLabel)
                .addGap(24, 24, 24)
                .addComponent(pemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(drugsbutton)
                    .addComponent(orderbutton))
                .addGap(72, 72, 72))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(JPIDLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(pidtext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JLastnameLabel)
                                    .addComponent(JFirstnameLabel))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(plnametext)
                                    .addComponent(pfnametext))))
                        .addGap(97, 97, 97)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JLastnameLabel2)
                                    .addComponent(JFirstnameLabel2)
                                    .addComponent(JIDLabel1))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(phemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(phfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(phlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(updatebutton)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(exitbutton))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(Juser_type_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JLastnameLabel1)
                .addGap(18, 18, 18)
                .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(JFirstnameLabel1)
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JFirstnameLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(JFirstnameLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(c_passtotext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(c_passfromtext, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c_userpassbutton)))
                .addGap(41, 41, 41))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(drugsbutton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(orderbutton))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(JLastnameLabel1)
                                .addComponent(userfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(JFirstnameLabel1)
                                .addComponent(userlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(c_passfromtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(c_userpassbutton)
                                .addComponent(JFirstnameLabel3))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Juser_type_Label)
                                .addComponent(useridtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(c_passtotext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JFirstnameLabel4))
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JLastnameLabel2)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(phfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(updatebutton)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JFirstnameLabel2)
                                    .addComponent(phlnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(phemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(JIDLabel1)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JPIDLabel)
                                    .addComponent(pidtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JLastnameLabel)
                                    .addComponent(pfnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JFirstnameLabel)
                                    .addComponent(plnametext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JIDLabel)
                            .addComponent(pemailtext, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 121, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(exitbutton))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void drugsbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drugsbuttonActionPerformed
        // TODO add your handling code here:
        new admindrugsjdialog2((connectloginjframe) SwingUtilities.getWindowAncestor(this),true,idvar3,passvar3,Juser_type_Label.getText()).setVisible(true);
    }//GEN-LAST:event_drugsbuttonActionPerformed

    private void orderbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderbuttonActionPerformed
        // TODO add your handling code here:
        new orderjdialog((connectloginjframe) SwingUtilities.getWindowAncestor(this),true,idvar3,passvar3,Juser_type_Label.getText()).setVisible(true);
    }//GEN-LAST:event_orderbuttonActionPerformed

    private void exitbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbuttonActionPerformed
        // TODO add your handling code here:

        exitAction();
    }//GEN-LAST:event_exitbuttonActionPerformed

    private void useridtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_useridtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_useridtextActionPerformed

    private void phemailtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phemailtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phemailtextActionPerformed

    private void updatebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebuttonActionPerformed
        // TODO add your handling code here:
        updatePharmacistAction();loaduserinfo(idvar3, passvar3);
    }//GEN-LAST:event_updatebuttonActionPerformed

    private void pemailtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pemailtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pemailtextActionPerformed

    private void pidtextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pidtextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pidtextActionPerformed

    private void c_userpassbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_userpassbuttonActionPerformed
        // TODO add your handling code here:
        executeStoredProcedure();
    }//GEN-LAST:event_c_userpassbuttonActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        // TODO add your handling code here:
        loadpharmacists();loadsellers();
    }//GEN-LAST:event_formComponentShown

    private void sellerjtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sellerjtableMouseClicked
        // TODO add your handling code here:
        STableMouseClickedAction();
    }//GEN-LAST:event_sellerjtableMouseClicked

    private void pharmacistjtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pharmacistjtableMouseClicked
        // TODO add your handling code here:
        PhTableMouseClickedAction();
    }//GEN-LAST:event_pharmacistjtableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pharmacistjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pharmacistjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pharmacistjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pharmacistjdialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                pharmacistjdialog dialog = new pharmacistjdialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JFirstnameLabel;
    private javax.swing.JLabel JFirstnameLabel1;
    private javax.swing.JLabel JFirstnameLabel2;
    private javax.swing.JLabel JFirstnameLabel3;
    private javax.swing.JLabel JFirstnameLabel4;
    private javax.swing.JLabel JIDLabel;
    private javax.swing.JLabel JIDLabel1;
    private javax.swing.JLabel JLastnameLabel;
    private javax.swing.JLabel JLastnameLabel1;
    private javax.swing.JLabel JLastnameLabel2;
    private javax.swing.JLabel JPIDLabel;
    private javax.swing.JLabel Juser_type_Label;
    private javax.swing.JTextField c_passfromtext;
    private javax.swing.JTextField c_passtotext;
    private javax.swing.JButton c_userpassbutton;
    private javax.swing.JButton drugsbutton;
    private javax.swing.JButton exitbutton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton orderbutton;
    private javax.swing.JTextField pemailtext;
    private javax.swing.JTextField pfnametext;
    private javax.swing.JTable pharmacistjtable;
    private javax.swing.JTextField phemailtext;
    private javax.swing.JTextField phfnametext;
    private javax.swing.JTextField phlnametext;
    private javax.swing.JTextField pidtext;
    private javax.swing.JTextField plnametext;
    private javax.swing.JTable sellerjtable;
    private javax.swing.JButton updatebutton;
    private javax.swing.JTextField userfnametext;
    private javax.swing.JTextField useridtext;
    private javax.swing.JTextField userlnametext;
    // End of variables declaration//GEN-END:variables
}
